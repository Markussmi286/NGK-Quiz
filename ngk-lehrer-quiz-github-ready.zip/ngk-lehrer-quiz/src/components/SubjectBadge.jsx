import React from "react";
import { SUBJECT_COLORS } from "../constants.js";

/**
 * Coloured pill badge for a single subject.
 * @param {{ subject: string, small?: boolean }} props
 */
export function SubjectBadge({ subject, small = false }) {
  const bg = SUBJECT_COLORS[subject] ?? "#555";
  return (
    <span
      style={{
        background:   bg,
        borderRadius: "0.4rem",
        padding:      small ? "0.15rem 0.45rem" : "0.2rem 0.6rem",
        fontSize:     small ? "0.72rem" : "0.85rem",
        fontWeight:   700,
        fontFamily:   "system-ui, sans-serif",
        color:        "#fff",
        display:      "inline-block",
      }}
    >
      {subject}
    </span>
  );
}
