import React from "react";
import { BLUR_LEVELS } from "../constants.js";

/**
 * Circular teacher photo with dynamic blur level.
 *
 * @param {{
 *   imgUrl:        string | null,
 *   clueStage:     number,
 *   loadingImages: boolean,
 * }} props
 */
export function TeacherPhoto({ imgUrl, clueStage, loadingImages }) {
  const blur = BLUR_LEVELS[Math.min(clueStage, BLUR_LEVELS.length - 1)];

  return (
    <div
      style={{
        width:        "130px",
        height:       "130px",
        borderRadius: "50%",
        overflow:     "hidden",
        flexShrink:   0,
        position:     "relative",
        border:       "3px solid rgba(0,208,132,0.3)",
        boxShadow:    "0 0 30px rgba(0,208,132,0.15)",
      }}
    >
      {imgUrl ? (
        <img
          src={imgUrl}
          alt="?"
          style={{
            width:      "100%",
            height:     "100%",
            objectFit:  "cover",
            filter:     `blur(${blur}px)`,
            transform:  blur > 0 ? "scale(1.1)" : "scale(1)",
            transition: "filter 0.8s ease, transform 0.8s ease",
          }}
        />
      ) : (
        <div
          style={{
            width:           "100%",
            height:          "100%",
            background:      "linear-gradient(135deg,#2d3436,#636e72)",
            display:         "flex",
            alignItems:      "center",
            justifyContent:  "center",
            fontSize:        "3rem",
          }}
        >
          {loadingImages ? (
            <span className="spin" style={{ fontSize: "1.2rem" }}>⟳</span>
          ) : (
            "🧑"
          )}
        </div>
      )}
    </div>
  );
}
