import React from "react";

/**
 * Purely decorative concentric pulsing rings rendered in the background.
 * @param {{ count?: number }} props
 */
export function DecorativeRings({ count = 6 }) {
  return (
    <>
      {Array.from({ length: count }, (_, i) => (
        <div
          key={i}
          style={{
            position:        "absolute",
            borderRadius:    "50%",
            width:           80 + i * 60 + "px",
            height:          80 + i * 60 + "px",
            border:          `1px solid rgba(0,208,132,${0.03 + i * 0.01})`,
            top:             "50%",
            left:            "50%",
            transform:       "translate(-50%,-50%)",
            animation:       `pulse ${3 + i}s ease-in-out infinite`,
            animationDelay:  `${i * 0.5}s`,
            pointerEvents:   "none",
          }}
        />
      ))}
    </>
  );
}
