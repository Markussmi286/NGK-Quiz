import React from "react";
import { SubjectBadge } from "./SubjectBadge.jsx";

const LABEL_STYLE = {
  fontSize:      "0.65rem",
  color:         "rgba(255,255,255,0.35)",
  textTransform: "uppercase",
  letterSpacing: "0.08em",
  marginBottom:  "0.2rem",
};

/**
 * Text clues revealed beside the photo, one per stage.
 *
 * @param {{
 *   teacher:   { name: string, subjects: string[] },
 *   clueStage: number,
 * }} props
 */
export function CluePanel({ teacher, clueStage }) {
  const lastName      = teacher.name.split(" ").pop();
  const lastInitial   = lastName[0];

  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      {/* Stage 0: mystery prompt */}
      {clueStage === 0 && (
        <div style={{ color: "rgba(255,255,255,0.35)", fontSize: "0.85rem", fontStyle: "italic" }}>
          Wer bin ich?
        </div>
      )}

      {/* Stage 1: subject count */}
      {clueStage >= 1 && (
        <div style={{ marginBottom: "0.5rem" }}>
          <div style={LABEL_STYLE}>Anzahl Fächer</div>
          <div style={{ fontSize: "1.1rem", fontWeight: 700 }}>
            {teacher.subjects.length}&nbsp;
            {teacher.subjects.length === 1 ? "Fach" : "Fächer"}
          </div>
        </div>
      )}

      {/* Stage 2: first subject */}
      {clueStage >= 2 && (
        <div style={{ marginBottom: "0.5rem" }}>
          <div style={LABEL_STYLE}>Erstes Fach</div>
          <SubjectBadge subject={teacher.subjects[0]} />
        </div>
      )}

      {/* Stage 3: last-name initial */}
      {clueStage >= 3 && (
        <div style={{ marginBottom: "0.5rem" }}>
          <div style={LABEL_STYLE}>Anfangsbuchstabe Nachname</div>
          <div
            style={{
              fontSize:   "2rem",
              fontWeight: 900,
              color:      "#00d084",
              textShadow: "0 0 20px rgba(0,208,132,0.4)",
            }}
          >
            {lastInitial}
          </div>
        </div>
      )}

      {/* Stage 4: all subjects */}
      {clueStage >= 4 && (
        <div>
          <div style={LABEL_STYLE}>Alle Fächer</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.3rem" }}>
            {teacher.subjects.map((s) => (
              <SubjectBadge key={s} subject={s} small />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
