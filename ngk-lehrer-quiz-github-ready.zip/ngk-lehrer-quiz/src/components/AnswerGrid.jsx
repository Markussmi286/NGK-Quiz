import React from "react";

/**
 * 2×2 grid of answer-choice buttons with correct/wrong highlight states.
 *
 * @param {{
 *   choices:     Array<{ name: string }>,
 *   teacher:     { name: string },
 *   selected:    string | null,
 *   shake:       boolean,
 *   onAnswer:    (choice: { name: string }) => void,
 * }} props
 */
export function AnswerGrid({ choices, teacher, selected, shake, onAnswer }) {
  return (
    <div
      style={{
        width:               "100%",
        maxWidth:            "560px",
        display:             "grid",
        gridTemplateColumns: "1fr 1fr",
        gap:                 "0.7rem",
        animation:           shake ? "shake 0.4s ease" : "none",
      }}
    >
      {choices.map((choice, i) => {
        const isSelected     = selected === choice.name;
        const isCorrectChoice = teacher && choice.name === teacher.name;

        let bg     = "rgba(255,255,255,0.05)";
        let border = "1px solid rgba(255,255,255,0.1)";
        let glow   = "none";

        if (selected) {
          if (isCorrectChoice) {
            bg     = "rgba(0,208,132,0.18)";
            border = "1px solid rgba(0,208,132,0.5)";
            glow   = "0 0 20px rgba(0,208,132,0.2)";
          } else if (isSelected) {
            bg     = "rgba(231,76,60,0.18)";
            border = "1px solid rgba(231,76,60,0.5)";
            glow   = "0 0 20px rgba(231,76,60,0.2)";
          }
        }

        return (
          <button
            key={choice.name}
            onClick={() => onAnswer(choice)}
            disabled={!!selected}
            onMouseEnter={(e) => {
              if (!selected) e.currentTarget.style.background = "rgba(255,255,255,0.1)";
            }}
            onMouseLeave={(e) => {
              if (!selected) e.currentTarget.style.background = bg;
            }}
            style={{
              background:   bg,
              border,
              borderRadius: "1rem",
              padding:      "0.9rem 0.7rem",
              color:        "#fff",
              fontSize:     "0.88rem",
              fontWeight:   600,
              cursor:       selected ? "default" : "pointer",
              textAlign:    "left",
              transition:   "all 0.2s",
              boxShadow:    glow,
              fontFamily:   "'Georgia', serif",
            }}
          >
            <span
              style={{
                display:     "inline-block",
                width:       "18px",
                height:      "18px",
                borderRadius:"50%",
                background:  "rgba(255,255,255,0.15)",
                textAlign:   "center",
                lineHeight:  "18px",
                fontSize:    "0.65rem",
                marginRight: "0.5rem",
                fontFamily:  "system-ui, sans-serif",
              }}
            >
              {String.fromCharCode(65 + i)}
            </span>
            {choice.name}
          </button>
        );
      })}
    </div>
  );
}
