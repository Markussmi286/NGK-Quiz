import { useState, useEffect, useRef, useCallback } from "react";
import { STAGE_TIMER_SECONDS } from "../constants.js";

/**
 * Countdown timer for quiz stages.
 *
 * @param {{
 *   active:      boolean,
 *   onTimeout:   () => void,
 * }} options
 * @returns {{
 *   timer:     number,
 *   resetTimer: () => void,
 * }}
 */
export function useQuizTimer({ active, onTimeout }) {
  const [timer, setTimer]   = useState(STAGE_TIMER_SECONDS);
  const intervalRef         = useRef(null);
  const onTimeoutRef        = useRef(onTimeout);

  // Keep the callback ref fresh without triggering effect re-runs
  useEffect(() => { onTimeoutRef.current = onTimeout; }, [onTimeout]);

  useEffect(() => {
    if (!active) {
      clearInterval(intervalRef.current);
      return;
    }

    intervalRef.current = setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          clearInterval(intervalRef.current);
          onTimeoutRef.current();
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => clearInterval(intervalRef.current);
  }, [active]);

  const resetTimer = useCallback(() => {
    clearInterval(intervalRef.current);
    setTimer(STAGE_TIMER_SECONDS);
  }, []);

  return { timer, resetTimer };
}
