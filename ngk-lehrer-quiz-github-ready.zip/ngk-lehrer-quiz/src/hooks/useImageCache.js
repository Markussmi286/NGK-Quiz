import { useState, useCallback } from "react";
import { fetchImageUrl } from "../utils/fetchImage.js";

const DELAY_MS = 200; // polite delay between API calls

/**
 * Manages a persistent in-memory image URL cache and provides a loader.
 *
 * @returns {{
 *   imageCache:    Record<string, string>,
 *   loadingImages: boolean,
 *   loadImages:    (teachers: Array<{ slug: string }>) => Promise<void>
 * }}
 */
export function useImageCache() {
  const [imageCache, setImageCache]     = useState({});
  const [loadingImages, setLoadingImages] = useState(false);

  const loadImages = useCallback(async (teachers) => {
    setLoadingImages(true);

    // Work with a local snapshot so we can batch the state update
    let localCache = {};
    setImageCache((prev) => { localCache = { ...prev }; return prev; });

    for (const teacher of teachers) {
      if (localCache[teacher.slug]) continue; // already cached

      const url = await fetchImageUrl(teacher.slug);
      if (url) {
        localCache[teacher.slug] = url;
        // Update state progressively so the UI can show images as they arrive
        setImageCache({ ...localCache });
      }

      await new Promise((r) => setTimeout(r, DELAY_MS));
    }

    setLoadingImages(false);
  }, []);

  return { imageCache, loadingImages, loadImages };
}
