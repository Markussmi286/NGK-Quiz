import { useState, useCallback } from "react";
import { TEACHERS }     from "./data/teachers.js";
import { CLUE_STAGES, QUIZ_LENGTH } from "./constants.js";
import { shuffle, getChoices }      from "./utils/quiz.js";
import { useImageCache }            from "./hooks/useImageCache.js";
import { StartScreen }  from "./screens/StartScreen.jsx";
import { QuizScreen }   from "./screens/QuizScreen.jsx";
import { EndScreen }    from "./screens/EndScreen.jsx";

/**
 * @typedef {"start"|"quiz"|"end"} Screen
 */

export default function App() {
  const [screen,     setScreen]     = useState(/** @type {Screen} */ ("start"));
  const [queue,      setQueue]      = useState([]);
  const [current,    setCurrent]    = useState(0);
  const [choices,    setChoices]    = useState([]);
  const [totalScore, setTotalScore] = useState(0);
  const [results,    setResults]    = useState([]);

  const { imageCache, loadingImages, loadImages } = useImageCache();

  // ── Start / restart quiz ──────────────────────────────────────
  const startQuiz = useCallback(() => {
    const q = shuffle(TEACHERS.filter((t) => t.subjects.length > 0)).slice(0, QUIZ_LENGTH);
    setQueue(q);
    setCurrent(0);
    setChoices(getChoices(q[0], TEACHERS));
    setTotalScore(0);
    setResults([]);
    setScreen("quiz");
    loadImages(q);
  }, [loadImages]);

  // ── Advance to next teacher ───────────────────────────────────
  const advanceOrEnd = useCallback(
    (updatedResults, q, idx) => {
      const next = idx + 1;
      if (next >= q.length) {
        setScreen("end");
      } else {
        setCurrent(next);
        setChoices(getChoices(q[next], TEACHERS));
      }
    },
    []
  );

  // ── Called by QuizScreen when the user picks an answer ───────
  const handleAnswer = useCallback(
    (choice, earned, correct) => {
      const teacher    = queue[current];
      const newResult  = { teacher, earned, correct };

      setResults((prev) => {
        const updated = [...prev, newResult];
        setTimeout(() => advanceOrEnd(updated, queue, current), 2000);
        return updated;
      });

      if (correct) setTotalScore((s) => s + earned);
    },
    [queue, current, advanceOrEnd]
  );

  // ── Called by QuizScreen when the final stage timer runs out ─
  const handleTimeout = useCallback(() => {
    const teacher   = queue[current];
    const newResult = { teacher, earned: 0, correct: false };

    setResults((prev) => {
      const updated = [...prev, newResult];
      setTimeout(() => advanceOrEnd(updated, queue, current), 1500);
      return updated;
    });
  }, [queue, current, advanceOrEnd]);

  // ── Render ───────────────────────────────────────────────────
  if (screen === "start") {
    return <StartScreen onStart={startQuiz} />;
  }

  if (screen === "end") {
    return (
      <EndScreen
        totalScore={totalScore}
        maxScore={queue.length * CLUE_STAGES[0].points}
        results={results}
        onRestart={startQuiz}
        onHome={() => setScreen("start")}
      />
    );
  }

  return (
    <QuizScreen
      key={current}           // remount on each new teacher to reset local state cleanly
      queue={queue}
      current={current}
      choices={choices}
      imageCache={imageCache}
      loadingImages={loadingImages}
      totalScore={totalScore}
      onAnswer={handleAnswer}
      onTimeout={handleTimeout}
    />
  );
}
