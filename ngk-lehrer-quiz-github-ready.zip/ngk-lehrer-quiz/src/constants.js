/** Base URL for teacher profile pages on the school website */
export const BASE_URL =
  "https://www.norbert-gymnasium.de/wir-am-ngk/kollegium/ansprechpartner/name/";

/** How many teachers are shown per quiz session */
export const QUIZ_LENGTH = 10;

/** Seconds per hint stage before auto-advancing */
export const STAGE_TIMER_SECONDS = 20;

/**
 * Clue stages, ordered from hardest to easiest.
 * key    – internal identifier used in components
 * label  – human-readable German description
 * points – score awarded if guessed at this stage
 */
export const CLUE_STAGES = [
  { key: "photoBlur3",  label: "Foto (stark verpixelt)",                    points: 500 },
  { key: "photoBlur2",  label: "Anzahl Fächer + Foto (weniger verpixelt)",   points: 400 },
  { key: "photoBlur1",  label: "Erstes Fach + Foto (leicht verpixelt)",      points: 300 },
  { key: "photoFull",   label: "Anfangsbuchstabe Nachname + klares Foto",    points: 200 },
  { key: "allSubjects", label: "Alle Fächer",                                points: 100 },
];

/** CSS blur in px for each clue stage index (matches CLUE_STAGES length) */
export const BLUR_LEVELS = [20, 10, 4, 0, 0];

/** Subject → accent color mapping */
export const SUBJECT_COLORS = {
  "Mathematik":          "#e74c3c",
  "Sport":               "#27ae60",
  "Deutsch":             "#3498db",
  "Englisch":            "#8e44ad",
  "Biologie":            "#16a085",
  "Physik":              "#d35400",
  "Chemie":              "#c0392b",
  "Geschichte":          "#95a5a6",
  "Kunst":               "#e67e22",
  "Musik":               "#9b59b6",
  "Latein":              "#795548",
  "Informatik":          "#2980b9",
  "Erdkunde":            "#1abc9c",
  "Französisch":         "#2c3e50",
  "Spanisch":            "#f39c12",
  "Kath. Religion":      "#8e44ad",
  "Ev. Religion":        "#6c5ce7",
  "Literatur":           "#fd79a8",
  "Sozialwissenschaften":"#0984e3",
  "Politik":             "#a29bfe",
  "Philosophie":         "#74b9ff",
  "Pädagogik":           "#fdcb6e",
  "Wirtschaft-Politik":  "#55efc4",
  "Bildende Kunst":      "#fd79a8",
  "Ernährungslehre":     "#badc58",
  "Griechisch":          "#f9ca24",
};
