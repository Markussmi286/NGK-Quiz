/**
 * Returns a new array with elements in random order (Fisher-Yates).
 * @template T
 * @param {T[]} arr
 * @returns {T[]}
 */
export function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Builds a shuffled array of 4 answer choices that always includes `correct`.
 * @param {{ name: string }} correct
 * @param {{ name: string }[]} all
 * @returns {{ name: string }[]}
 */
export function getChoices(correct, all) {
  const distractors = shuffle(all.filter((t) => t.name !== correct.name)).slice(0, 3);
  return shuffle([correct, ...distractors]);
}
