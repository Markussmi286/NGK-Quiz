import { BASE_URL } from "../constants.js";

const IMAGE_PATTERN =
  /https:\/\/www\.norbert-gymnasium\.de\/wp-content\/uploads\/[^\s"'<>]+\.(?:jpg|jpeg|png|webp)/i;

/**
 * Uses the Anthropic API with web_search to find the og:image URL
 * for a teacher's profile page.
 *
 * @param {string} slug  – URL slug from the teacher data
 * @returns {Promise<string|null>}  resolved image URL, or null on failure
 */
export async function fetchImageUrl(slug) {
  const profileUrl = `${BASE_URL}${slug}/`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 300,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [
          {
            role: "user",
            content: `Search for the og:image meta tag URL from this page: ${profileUrl}
Return ONLY the image URL, nothing else. It looks like: https://www.norbert-gymnasium.de/wp-content/uploads/...`,
          },
        ],
      }),
    });

    if (!response.ok) {
      console.warn(`[fetchImageUrl] HTTP ${response.status} for slug "${slug}"`);
      return null;
    }

    const data = await response.json();
    const text = (data.content ?? [])
      .map((block) => block.text ?? "")
      .join("");

    const match = text.match(IMAGE_PATTERN);
    return match ? match[0] : null;
  } catch (err) {
    console.error(`[fetchImageUrl] Error for slug "${slug}":`, err);
    return null;
  }
}
