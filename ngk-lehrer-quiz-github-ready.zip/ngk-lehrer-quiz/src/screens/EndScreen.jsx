import React from "react";

/**
 * Results / end screen shown after the final question.
 *
 * @param {{
 *   totalScore: number,
 *   maxScore:   number,
 *   results:    Array<{ teacher: { name: string }, earned: number, correct: boolean }>,
 *   onRestart:  () => void,
 *   onHome:     () => void,
 * }} props
 */
export function EndScreen({ totalScore, maxScore, results, onRestart, onHome }) {
  const pct   = Math.round((totalScore / maxScore) * 100);
  const emoji = pct >= 80 ? "🏆" : pct >= 50 ? "⭐" : "🎓";
  const msg   =
    pct >= 80
      ? "Ausgezeichnet! Du kennst dein Kollegium!"
      : pct >= 50
      ? "Gut gemacht! Noch ein bisschen üben."
      : "Weiter üben – du schaffst das!";

  return (
    <div
      style={{
        minHeight:      "100vh",
        background:     "linear-gradient(135deg,#0d1117,#161b22)",
        fontFamily:     "'Georgia', serif",
        color:          "#fff",
        padding:        "1.5rem",
        display:        "flex",
        flexDirection:  "column",
        alignItems:     "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          background:   "rgba(255,255,255,0.04)",
          border:       "1px solid rgba(0,208,132,0.25)",
          borderRadius: "2rem",
          padding:      "2.5rem",
          maxWidth:     "580px",
          width:        "100%",
        }}
      >
        {/* Score summary */}
        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <div style={{ fontSize: "4rem" }}>{emoji}</div>
          <h2 style={{ fontSize: "2rem", margin: "0.5rem 0", fontFamily: "'Georgia',serif" }}>
            Quiz beendet!
          </h2>
          <div style={{ fontSize: "3rem", fontWeight: 900, color: "#00d084" }}>
            {totalScore}
          </div>
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.8rem" }}>
            von {maxScore} möglichen Punkten
          </div>
          <div style={{ color: "#f9ca24", marginTop: "0.5rem", fontSize: "0.9rem" }}>
            {msg}
          </div>
        </div>

        {/* Per-question breakdown */}
        <div
          style={{
            display:       "flex",
            flexDirection: "column",
            gap:           "0.5rem",
            marginBottom:  "2rem",
          }}
        >
          {results.map((r, i) => (
            <div
              key={i}
              style={{
                display:        "flex",
                justifyContent: "space-between",
                alignItems:     "center",
                background:     r.correct ? "rgba(0,208,132,0.1)" : "rgba(231,76,60,0.08)",
                border:         `1px solid ${r.correct ? "rgba(0,208,132,0.25)" : "rgba(231,76,60,0.2)"}`,
                borderRadius:   "0.6rem",
                padding:        "0.55rem 0.9rem",
                fontSize:       "0.83rem",
              }}
            >
              <span>
                {r.correct ? "✅" : "❌"}&nbsp;{r.teacher.name}
              </span>
              <span
                style={{
                  fontWeight: 700,
                  color:      r.correct ? "#00d084" : "#e74c3c",
                  marginLeft: "0.5rem",
                  flexShrink: 0,
                }}
              >
                {r.earned > 0 ? `+${r.earned}` : "0"} Pkt
              </span>
            </div>
          ))}
        </div>

        {/* Action buttons */}
        <div style={{ display: "flex", gap: "1rem", justifyContent: "center" }}>
          <button
            onClick={onRestart}
            style={{
              background:   "linear-gradient(135deg,#00d084,#00b4d8)",
              border:       "none",
              borderRadius: "0.8rem",
              padding:      "0.8rem 1.8rem",
              color:        "#fff",
              fontSize:     "0.95rem",
              fontWeight:   700,
              cursor:       "pointer",
            }}
          >
            Nochmal spielen
          </button>
          <button
            onClick={onHome}
            style={{
              background:   "rgba(255,255,255,0.08)",
              border:       "1px solid rgba(255,255,255,0.15)",
              borderRadius: "0.8rem",
              padding:      "0.8rem 1.8rem",
              color:        "rgba(255,255,255,0.7)",
              fontSize:     "0.95rem",
              cursor:       "pointer",
            }}
          >
            Startseite
          </button>
        </div>
      </div>
    </div>
  );
}
