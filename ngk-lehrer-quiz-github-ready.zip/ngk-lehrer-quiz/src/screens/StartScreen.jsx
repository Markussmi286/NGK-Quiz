import React from "react";
import { CLUE_STAGES } from "../constants.js";
import { DecorativeRings } from "../components/DecorativeRings.jsx";

/**
 * Start / welcome screen.
 * @param {{ onStart: () => void }} props
 */
export function StartScreen({ onStart }) {
  return (
    <div
      style={{
        minHeight:      "100vh",
        background:     "linear-gradient(135deg,#0d1117 0%,#161b22 50%,#0d1117 100%)",
        display:        "flex",
        flexDirection:  "column",
        alignItems:     "center",
        justifyContent: "center",
        fontFamily:     "'Georgia', serif",
        color:          "#fff",
        padding:        "2rem",
        position:       "relative",
        overflow:       "hidden",
      }}
    >
      <DecorativeRings count={6} />

      <div
        style={{
          background:   "rgba(255,255,255,0.04)",
          border:       "1px solid rgba(0,208,132,0.25)",
          borderRadius: "2rem",
          padding:      "3rem 3.5rem",
          maxWidth:     "480px",
          width:        "100%",
          textAlign:    "center",
          position:     "relative",
          boxShadow:    "0 0 80px rgba(0,208,132,0.08), inset 0 0 40px rgba(255,255,255,0.01)",
        }}
      >
        <div style={{ fontSize: "3.5rem", marginBottom: "0.5rem" }}>🏫</div>

        <div
          style={{
            fontSize:      "0.7rem",
            letterSpacing: "0.3em",
            color:         "#00d084",
            textTransform: "uppercase",
            marginBottom:  "0.8rem",
          }}
        >
          Norbert-Gymnasium Knechtsteden
        </div>

        <h1
          style={{
            fontSize:               "2.6rem",
            fontWeight:             900,
            margin:                 "0 0 0.3rem",
            fontFamily:             "'Georgia', serif",
            background:             "linear-gradient(135deg,#fff 0%,#a8edea 100%)",
            WebkitBackgroundClip:   "text",
            WebkitTextFillColor:    "transparent",
            lineHeight:             1.1,
          }}
        >
          Lehrer-Quiz
        </h1>

        <p
          style={{
            color:         "rgba(255,255,255,0.55)",
            lineHeight:    1.7,
            marginBottom:  "2rem",
            fontSize:      "0.88rem",
          }}
        >
          Erkenne deine Lehrer anhand des verpixelten Fotos und weiterer Hinweise.
          Je früher du rätst, desto mehr Punkte bekommst du!
        </p>

        {/* Scoring overview */}
        <div
          style={{
            display:       "flex",
            flexDirection: "column",
            gap:           "0.5rem",
            marginBottom:  "2rem",
          }}
        >
          {CLUE_STAGES.map((s, i) => (
            <div
              key={s.key}
              style={{
                display:        "flex",
                justifyContent: "space-between",
                alignItems:     "center",
                background:     "rgba(255,255,255,0.04)",
                borderRadius:   "0.5rem",
                padding:        "0.45rem 0.8rem",
              }}
            >
              <span style={{ color: "rgba(255,255,255,0.65)", fontSize: "0.8rem" }}>
                <span style={{ color: "rgba(255,255,255,0.35)", marginRight: "0.5rem" }}>
                  {i + 1}.
                </span>
                {s.label}
              </span>
              <span
                style={{
                  color:      "#f9ca24",
                  fontWeight: 700,
                  fontSize:   "0.85rem",
                  marginLeft: "1rem",
                  flexShrink: 0,
                }}
              >
                {s.points}P
              </span>
            </div>
          ))}
        </div>

        <button
          onClick={onStart}
          onMouseEnter={(e) => {
            e.target.style.transform = "scale(1.04)";
            e.target.style.boxShadow = "0 8px 30px rgba(0,208,132,0.45)";
          }}
          onMouseLeave={(e) => {
            e.target.style.transform = "scale(1)";
            e.target.style.boxShadow = "0 4px 20px rgba(0,208,132,0.3)";
          }}
          style={{
            background:    "linear-gradient(135deg,#00d084,#00b4d8)",
            border:        "none",
            borderRadius:  "1rem",
            padding:       "0.9rem 2.5rem",
            color:         "#fff",
            fontSize:      "1rem",
            fontWeight:    700,
            cursor:        "pointer",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            boxShadow:     "0 4px 20px rgba(0,208,132,0.3)",
            transition:    "all 0.2s",
          }}
        >
          Quiz starten →
        </button>
      </div>

      <style>{`
        @keyframes pulse {
          0%,100% { opacity: 0.3; transform: translate(-50%,-50%) scale(1); }
          50%      { opacity: 0.6; transform: translate(-50%,-50%) scale(1.04); }
        }
      `}</style>
    </div>
  );
}
