import React, { useState, useCallback, useEffect, useRef } from "react";
import { CLUE_STAGES, STAGE_TIMER_SECONDS } from "../constants.js";
import { TeacherPhoto } from "../components/TeacherPhoto.jsx";
import { CluePanel }    from "../components/CluePanel.jsx";
import { AnswerGrid }   from "../components/AnswerGrid.jsx";

/**
 * Full quiz gameplay screen.
 *
 * @param {{
 *   queue:         Array<Teacher>,
 *   current:       number,
 *   choices:       Array<Teacher>,
 *   imageCache:    Record<string, string>,
 *   loadingImages: boolean,
 *   totalScore:    number,
 *   onAnswer:      (choice: Teacher) => void,
 *   onTimeout:     () => void,
 * }} props
 */
export function QuizScreen({
  queue,
  current,
  choices,
  imageCache,
  loadingImages,
  totalScore,
  onAnswer,
  onTimeout,
}) {
  const teacher = queue[current];
  const imgUrl  = teacher ? imageCache[teacher.slug] : null;

  // ── Local state ──────────────────────────────────────────────
  const [clueStage,  setClueStage]  = useState(0);
  const [roundScore, setRoundScore] = useState(CLUE_STAGES[0].points);
  const [selected,   setSelected]   = useState(null);
  const [shake,      setShake]      = useState(false);
  const [timer,      setTimer]      = useState(STAGE_TIMER_SECONDS);
  const [timerActive,setTimerActive]= useState(true);
  const timerRef = useRef(null);

  // Reset local state when the teacher changes
  useEffect(() => {
    setClueStage(0);
    setRoundScore(CLUE_STAGES[0].points);
    setSelected(null);
    setShake(false);
    setTimer(STAGE_TIMER_SECONDS);
    setTimerActive(true);
  }, [current]);

  // Countdown
  useEffect(() => {
    if (!timerActive || selected) return;

    timerRef.current = setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current);
          setTimerActive(false);

          setClueStage((cs) => {
            if (cs < CLUE_STAGES.length - 1) {
              const next = cs + 1;
              setRoundScore(CLUE_STAGES[next].points);
              setTimer(STAGE_TIMER_SECONDS);
              setTimerActive(true);
              return next;
            }
            // Timed out on last stage
            onTimeout();
            return cs;
          });

          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [timerActive, selected, onTimeout]);

  // ── Handlers ─────────────────────────────────────────────────
  const handleAnswer = useCallback(
    (choice) => {
      if (selected) return;
      clearInterval(timerRef.current);
      setTimerActive(false);
      setSelected(choice.name);

      const correct = choice.name === teacher.name;
      if (!correct) {
        setShake(true);
        setTimeout(() => setShake(false), 500);
      }
      onAnswer(choice, correct ? roundScore : 0, correct);
    },
    [selected, teacher, roundScore, onAnswer]
  );

  const handleNextClue = () => {
    const next = clueStage + 1;
    setClueStage(next);
    setRoundScore(CLUE_STAGES[next].points);
    setTimer(STAGE_TIMER_SECONDS);
  };

  // ── Derived values ────────────────────────────────────────────
  const timerPct   = (timer / STAGE_TIMER_SECONDS) * 100;
  const timerColor = timer > 10 ? "#00d084" : timer > 5 ? "#f9ca24" : "#e74c3c";

  if (!teacher) return null;

  return (
    <div
      style={{
        minHeight:      "100vh",
        background:     "linear-gradient(135deg,#0d1117 0%,#161b22 50%,#0d1117 100%)",
        fontFamily:     "'Georgia', serif",
        color:          "#fff",
        display:        "flex",
        flexDirection:  "column",
        alignItems:     "center",
        padding:        "1.2rem 1rem 2rem",
      }}
    >
      {/* ── Header ─────────────────────────────────────── */}
      <div
        style={{
          width:          "100%",
          maxWidth:       "560px",
          display:        "flex",
          justifyContent: "space-between",
          alignItems:     "center",
          marginBottom:   "1rem",
        }}
      >
        <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", letterSpacing: "0.1em" }}>
          FRAGE {current + 1}/{queue.length}
        </div>
        <div
          style={{
            fontSize:   "1.6rem",
            fontWeight: 900,
            color:      "#f9ca24",
            textShadow: "0 0 20px rgba(249,202,36,0.4)",
          }}
        >
          {totalScore} Pkt
        </div>
      </div>

      {/* ── Timer bar ──────────────────────────────────── */}
      <div
        style={{
          width:        "100%",
          maxWidth:     "560px",
          height:       "5px",
          background:   "rgba(255,255,255,0.08)",
          borderRadius: "3px",
          marginBottom: "1.2rem",
          overflow:     "hidden",
        }}
      >
        <div
          style={{
            height:     "100%",
            borderRadius:"3px",
            width:       timerPct + "%",
            background:  timerColor,
            transition:  "width 1s linear, background 0.3s",
            boxShadow:  `0 0 8px ${timerColor}`,
          }}
        />
      </div>

      {/* ── Main card ──────────────────────────────────── */}
      <div
        style={{
          width:        "100%",
          maxWidth:     "560px",
          background:   "rgba(255,255,255,0.035)",
          border:       "1px solid rgba(255,255,255,0.09)",
          borderRadius: "1.5rem",
          overflow:     "hidden",
          marginBottom: "1rem",
        }}
      >
        {/* Photo + clue text */}
        <div
          style={{
            background:     "rgba(0,0,0,0.3)",
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            padding:        "1.5rem",
            gap:            "1.5rem",
            borderBottom:   "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <TeacherPhoto imgUrl={imgUrl} clueStage={clueStage} loadingImages={loadingImages} />
          <CluePanel teacher={teacher} clueStage={clueStage} />
        </div>

        {/* Hint progress pills */}
        <div
          style={{
            display:        "flex",
            padding:        "0.7rem 1.2rem",
            gap:            "0.4rem",
            alignItems:     "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.3)", letterSpacing: "0.05em" }}>
            HINWEIS {clueStage + 1}/5
          </div>
          <div style={{ display: "flex", gap: "0.3rem" }}>
            {CLUE_STAGES.map((_, i) => (
              <div
                key={i}
                style={{
                  width:      "28px",
                  height:     "5px",
                  borderRadius:"3px",
                  background:  i <= clueStage ? "#00d084" : "rgba(255,255,255,0.12)",
                  transition: "background 0.4s",
                }}
              />
            ))}
          </div>
          <div
            style={{
              fontSize:             "0.8rem",
              fontWeight:           700,
              background:           "linear-gradient(135deg,#f9ca24,#f0932b)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor:  "transparent",
            }}
          >
            {roundScore} P
          </div>
        </div>
      </div>

      {/* ── Next-clue button ───────────────────────────── */}
      {clueStage < CLUE_STAGES.length - 1 && !selected && (
        <button
          onClick={handleNextClue}
          onMouseEnter={(e) => (e.target.style.background = "rgba(255,255,255,0.13)")}
          onMouseLeave={(e) => (e.target.style.background = "rgba(255,255,255,0.07)")}
          style={{
            background:   "rgba(255,255,255,0.07)",
            border:       "1px solid rgba(255,255,255,0.15)",
            borderRadius: "0.6rem",
            padding:      "0.45rem 1rem",
            color:        "rgba(255,255,255,0.6)",
            fontSize:     "0.78rem",
            cursor:       "pointer",
            marginBottom: "1rem",
            transition:   "all 0.2s",
          }}
        >
          ↓ Nächster Hinweis (−{CLUE_STAGES[clueStage].points - CLUE_STAGES[clueStage + 1].points} Pkt)
        </button>
      )}

      {/* ── Answer grid ────────────────────────────────── */}
      <AnswerGrid
        choices={choices}
        teacher={teacher}
        selected={selected}
        shake={shake}
        onAnswer={handleAnswer}
      />

      {/* ── Countdown number ───────────────────────────── */}
      <div style={{ marginTop: "1.2rem", textAlign: "center" }}>
        <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.3)", letterSpacing: "0.1em", textTransform: "uppercase" }}>
          Verbleibend
        </div>
        <div
          style={{
            fontSize:   "2.2rem",
            fontWeight: 900,
            color:      timerColor,
            textShadow: `0 0 20px ${timerColor}44`,
          }}
        >
          {timer}s
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%,100% { transform: translateX(0); }
          20%     { transform: translateX(-8px); }
          40%     { transform: translateX(8px); }
          60%     { transform: translateX(-6px); }
          80%     { transform: translateX(6px); }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
