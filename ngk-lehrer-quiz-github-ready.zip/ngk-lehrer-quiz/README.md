# NGK Lehrer Quiz

Ein interaktives Lehrer-Quiz mit React + Vite.

## Funktionen
- Lehrer erkennen
- Quiz-Logik
- Timer
- Punkte-System
- Bilder-Cache
- Responsive Design

## Lokal starten

```bash
npm install
npm run dev
```

## Für GitHub vorbereiten

1. Neues Repository auf GitHub erstellen
2. Projekt hochladen:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin DEIN_GITHUB_LINK
git push -u origin main
```

## GitHub Pages aktivieren

1. GitHub Repository öffnen
2. Settings → Pages
3. Source = GitHub Actions

Danach wird die Website automatisch veröffentlicht.

## Build erstellen

```bash
npm run build
```

## Vorschau des Builds

```bash
npm run preview
```