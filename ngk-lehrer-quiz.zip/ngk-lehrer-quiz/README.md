# 🏫 NGK Lehrer-Quiz

Erkenne deine Lehrerinnen und Lehrer am **Norbert-Gymnasium Knechtsteden** anhand eines verpixelten Fotos und schrittweise aufgedeckter Hinweise.

---

## Spielprinzip

| Stufe | Hinweis                             | Punkte |
|------:|-------------------------------------|-------:|
| 1     | Nur verpixeltes Foto                |    500 |
| 2     | Anzahl Fächer + weniger verpixelt   |    400 |
| 3     | Erstes Fach + leicht verpixelt      |    300 |
| 4     | Anfangsbuchstabe Nachname + klares Foto | 200 |
| 5     | Alle Fächer                         |    100 |

Je früher du rätst, desto mehr Punkte! Pro Hinweis hast du **20 Sekunden** Zeit, bevor der nächste automatisch aufgedeckt wird.

---

## Technologie

| Schicht        | Tool                                  |
|----------------|---------------------------------------|
| UI-Framework   | [React 18](https://react.dev)         |
| Build-Tool     | [Vite 5](https://vitejs.dev)          |
| Foto-Laden     | Anthropic API (`claude-sonnet-4`) + Web-Search |
| Deployment     | Jede statische Hosting-Plattform (z. B. Vercel, Netlify, GitHub Pages) |

---

## Lokale Entwicklung

```bash
# 1. Repository klonen
git clone https://github.com/DEIN_USERNAME/ngk-lehrer-quiz.git
cd ngk-lehrer-quiz

# 2. Abhängigkeiten installieren
npm install

# 3. Entwicklungsserver starten
npm run dev
```

Öffne anschließend [http://localhost:5173](http://localhost:5173).

---

## Produktions-Build

```bash
npm run build      # Ausgabe in dist/
npm run preview    # Vorschau des Builds lokal testen
```

---

## Deployment auf GitHub Pages

```bash
# gh-pages Paket einmalig installieren
npm install -D gh-pages

# In package.json unter "scripts" hinzufügen:
# "deploy": "gh-pages -d dist"

npm run build
npm run deploy
```

> **Hinweis:** In `vite.config.js` ist `base: "./"` gesetzt, damit relative Pfade auch auf GitHub Pages korrekt funktionieren.

---

## Projektstruktur

```
ngk-lehrer-quiz/
├── index.html                  # HTML-Einstiegspunkt
├── vite.config.js              # Vite-Konfiguration
├── package.json
├── .gitignore
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx                # React-Einstiegspunkt
    ├── App.jsx                 # Root-Komponente & Quiz-Zustand
    ├── index.css               # Globale Styles & Animationen
    ├── constants.js            # Quiz-Konfiguration (Hinweisstufen, Farben …)
    ├── data/
    │   └── teachers.js         # Lehrerdaten (Name, Slug, Fächer)
    ├── utils/
    │   ├── quiz.js             # Hilfsfunktionen (shuffle, getChoices)
    │   └── fetchImage.js       # Anthropic-API-Aufruf zum Foto-Laden
    ├── hooks/
    │   ├── useImageCache.js    # Persistenter Foto-Cache
    │   └── useQuizTimer.js     # Countdown-Timer-Hook
    ├── components/
    │   ├── SubjectBadge.jsx    # Farbiges Fach-Badge
    │   ├── DecorativeRings.jsx # Animierte Hintergrundkreise
    │   ├── TeacherPhoto.jsx    # Verpixeltes Foto mit Fallback
    │   ├── CluePanel.jsx       # Text-Hinweise neben dem Foto
    │   └── AnswerGrid.jsx      # 2×2 Antwort-Buttons
    └── screens/
        ├── StartScreen.jsx     # Startseite
        ├── QuizScreen.jsx      # Hauptspiel
        └── EndScreen.jsx       # Ergebnisseite
```

---

## Lehrerdaten aktualisieren

Alle Lehrerdaten liegen in **`src/data/teachers.js`**.  
Jeder Eintrag folgt diesem Schema:

```js
{ name: "Vorname Nachname", slug: "url-slug-auf-schulwebsite", subjects: ["Fach1", "Fach2"] }
```

Der `slug` entspricht dem URL-Pfad auf  
`https://www.norbert-gymnasium.de/wir-am-ngk/kollegium/ansprechpartner/name/<slug>/`

---

## Lizenz

Dieses Projekt ist für den schulinternen Gebrauch am Norbert-Gymnasium Knechtsteden gedacht.
